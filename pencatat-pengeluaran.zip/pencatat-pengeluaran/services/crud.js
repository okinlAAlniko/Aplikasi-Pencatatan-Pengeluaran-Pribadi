import { ambilSemua, simpanSemua, buatId } from '../data/store.js';

// ---------- CREATE ----------
export const tambahPengeluaran = (dataBaru) => {
  const itemBaru = { id: buatId(), ...dataBaru };
  simpanSemua([...ambilSemua(), itemBaru]);
  return itemBaru;
};

// ---------- READ ----------
export const tampilkanSemua = () => ambilSemua();

export const cariById = (id) => ambilSemua().find((item) => item.id === id);

export const filterByKategori = (kategori) =>
  ambilSemua().filter((item) => item.kategori.toLowerCase() === kategori.toLowerCase());

export const adaKategori = (kategori) =>
  ambilSemua().some((item) => item.kategori.toLowerCase() === kategori.toLowerCase());

export const hitungTotal = (daftar = ambilSemua()) =>
  daftar.reduce((total, { jumlah }) => total + jumlah, 0);

export const ringkasanPerKategori = () =>
  ambilSemua().reduce((hasil, { kategori, jumlah }) => ({
    ...hasil,
    [kategori]: (hasil[kategori] ?? 0) + jumlah,
  }), {});

// ---------- UPDATE ----------
export const ubahPengeluaran = (id, perubahan) => {
  if (!cariById(id)) {
    return null;
  }

  let hasil = null;
  const dataBaru = ambilSemua().map((item) => {
    if (item.id === id) {
      hasil = { ...item, ...perubahan };
      return hasil;
    }
    return item;
  });

  simpanSemua(dataBaru);
  return hasil;
};

// ---------- DELETE ----------
export const hapusPengeluaran = (id) => {
  const target = cariById(id);
  if (!target) {
    return null;
  }

  simpanSemua(ambilSemua().filter((item) => item.id !== id));
  return target;
};
