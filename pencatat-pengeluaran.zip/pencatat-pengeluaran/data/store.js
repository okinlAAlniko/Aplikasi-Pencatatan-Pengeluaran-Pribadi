// Penyimpanan data: Array of Objects (disimpan di memori)
let daftarPengeluaran = [
  { id: 1, nama: 'Nasi Goreng', kategori: 'Makanan', jumlah: 15000, tanggal: '2026-10-20' },
  { id: 2, nama: 'Ojek Online', kategori: 'Transportasi', jumlah: 22000, tanggal: '2026-10-21' },
  { id: 3, nama: 'Kopi Susu', kategori: 'Makanan', jumlah: 18000, tanggal: '2026-10-22' },
];

let idBerikutnya = 4;

// Mengembalikan salinan array (spread) agar data asli tidak termutasi dari luar
export const ambilSemua = () => [...daftarPengeluaran];

export const simpanSemua = (dataBaru) => {
  daftarPengeluaran = [...dataBaru];
};

export const buatId = () => {
  const id = idBerikutnya;
  idBerikutnya += 1;
  return id;
};
