# Aplikasi Pencatat Pengeluaran Harian Berbasis CLI

## Gambaran Umum
Aplikasi terminal sederhana untuk mencatat pengeluaran sehari-hari (makan, transportasi, hiburan, dll). Pengguna dapat **menambah, melihat, mengubah, dan menghapus** catatan pengeluaran, mencari berdasarkan kategori, serta melihat total dan ringkasan pengeluaran per kategori. Data disimpan sementara di memori dalam bentuk Array of Objects.

## Cara Menjalankan Program (How to Run)
Prasyarat: [Node.js](https://nodejs.org) versi 16 atau lebih baru.

```bash
# 1. Clone repository
git clone <link-repository-kamu>
cd pencatat-pengeluaran

# 2. Jalankan aplikasi
node app.js
# atau
npm start
```

Ikuti menu yang tampil di terminal (ketik angka 0-6 lalu tekan Enter).

## Format Data
Data disimpan dalam Array of Objects di `data/store.js`:

```js
[
  { id: 1, nama: 'Nasi Goreng', kategori: 'Makanan', jumlah: 15000, tanggal: '2026-10-20' },
  { id: 2, nama: 'Ojek Online', kategori: 'Transportasi', jumlah: 22000, tanggal: '2026-10-21' }
]
```

| Key        | Tipe   | Keterangan                                   |
|------------|--------|----------------------------------------------|
| `id`       | Number | ID unik, dibuat otomatis (auto increment)    |
| `nama`     | String | Nama pengeluaran (maks. 50 karakter)         |
| `kategori` | String | Kategori, mis. Makanan, Transportasi, Hiburan|
| `jumlah`   | Number | Nominal dalam Rupiah (bilangan bulat > 0)    |
| `tanggal`  | String | Format `YYYY-MM-DD`                          |

## Struktur Folder
```
pencatat-pengeluaran/
├── app.js               # Program utama: menu & alur input/output
├── package.json         # "type": "module" untuk import/export ES Module
├── data/
│   └── store.js         # Penyimpanan Array of Objects
├── services/
│   └── crud.js          # Fungsi-fungsi CRUD
└── utils/
    ├── input.js         # Membaca input dari terminal
    ├── tampilan.js      # Format dan cetak output
    └── validasi.js      # Validasi input
```

## Penjelasan Function CRUD (`services/crud.js`)
| Operasi | Function | Peran |
|---------|----------|-------|
| **Create** | `tambahPengeluaran(dataBaru)` | Membuat object baru dengan `id` otomatis, lalu menambahkannya ke array memakai spread operator. |
| **Read** | `tampilkanSemua()` | Mengembalikan seluruh data pengeluaran. |
| | `cariById(id)` | Mencari satu data berdasarkan ID (`.find()`). |
| | `filterByKategori(kategori)` | Menyaring data berdasarkan kategori (`.filter()`). |
| | `hitungTotal(daftar)` | Menjumlahkan seluruh nominal (`.reduce()`). |
| | `ringkasanPerKategori()` | Mengelompokkan total pengeluaran per kategori (`.reduce()`). |
| | `adaKategori(kategori)` | Mengecek apakah kategori ada (`.some()`). |
| **Update** | `ubahPengeluaran(id, perubahan)` | Mengganti field tertentu pada data dengan ID terkait (`.map()` + spread), mengembalikan `null` jika ID tidak ada. |
| **Delete** | `hapusPengeluaran(id)` | Menghapus data berdasarkan ID (`.filter()`), mengembalikan `null` jika ID tidak ada. |

## Fitur yang Diterapkan
- **Wajib:** CRUD, Array of Objects, modularisasi (import/export), I/O Node.js (`readline`), `const`/`let`, `if/else` + `switch` + perulangan (`while`, `for...of`), Arrow Function.
- **Bonus:** Array methods (`map`, `filter`, `reduce`, `some`, `find`), spread operator, destructuring, template literals, dan validasi input (`===`, `!==`, `&&`, `||`, `!`).
