import {
  tambahPengeluaran,
  tampilkanSemua,
  cariById,
  filterByKategori,
  adaKategori,
  hitungTotal,
  ringkasanPerKategori,
  ubahPengeluaran,
  hapusPengeluaran,
} from './services/crud.js';
import { validasiNama, validasiJumlah, validasiTanggal, validasiId } from './utils/validasi.js';
import { tanya, tutupInput } from './utils/input.js';
import { cetakMenu, cetakTabel, cetakRingkasan, formatRupiah } from './utils/tampilan.js';

const tanggalHariIni = () => new Date().toLocaleDateString('en-CA'); // format YYYY-MM-DD

// ---------- Handler menu ----------
const handleTambah = async () => {
  console.log('\n--- Tambah Pengeluaran ---');
  const nama = await tanya('Nama pengeluaran : ');
  const kategori = await tanya('Kategori (mis. Makanan/Transportasi/Hiburan): ');
  const jumlah = Number(await tanya('Jumlah (Rp)       : '));
  const tanggalInput = await tanya(`Tanggal (YYYY-MM-DD, kosongkan = ${tanggalHariIni()}): `);
  const tanggal = tanggalInput === '' ? tanggalHariIni() : tanggalInput;

  if (!validasiNama(nama) || kategori === '') {
    console.log('❌ Nama dan kategori wajib diisi (nama maksimal 50 karakter).');
    return;
  }
  if (!validasiJumlah(jumlah)) {
    console.log('❌ Jumlah harus berupa bilangan bulat lebih dari 0.');
    return;
  }
  if (!validasiTanggal(tanggal)) {
    console.log('❌ Format tanggal salah. Gunakan YYYY-MM-DD, contoh 2026-10-23.');
    return;
  }

  const { id, nama: namaBaru } = tambahPengeluaran({ nama, kategori, jumlah, tanggal });
  console.log(`✅ Berhasil menambah "${namaBaru}" dengan ID ${id}.`);
};

const handleLihat = () => {
  const daftar = tampilkanSemua();
  cetakTabel(daftar);
  console.log(`\nTotal ${daftar.length} data | Total pengeluaran: ${formatRupiah(hitungTotal(daftar))}`);
};

const handleUbah = async () => {
  console.log('\n--- Ubah Pengeluaran ---');
  handleLihat();
  const id = Number(await tanya('\nMasukkan ID yang ingin diubah: '));

  if (!validasiId(id)) {
    console.log('❌ ID tidak valid.');
    return;
  }

  const dataLama = cariById(id);
  if (!dataLama) {
    console.log(`❌ Data dengan ID ${id} tidak ditemukan.`);
    return;
  }

  const { nama, kategori, jumlah, tanggal } = dataLama;
  console.log('(Kosongkan input jika tidak ingin mengubah field tersebut)');
  const namaBaru = await tanya(`Nama [${nama}]: `);
  const kategoriBaru = await tanya(`Kategori [${kategori}]: `);
  const jumlahInput = await tanya(`Jumlah [${jumlah}]: `);
  const tanggalBaru = await tanya(`Tanggal [${tanggal}]: `);

  const perubahan = {};

  if (namaBaru !== '') {
    if (!validasiNama(namaBaru)) {
      console.log('❌ Nama tidak valid (maksimal 50 karakter).');
      return;
    }
    perubahan.nama = namaBaru;
  }
  if (kategoriBaru !== '') {
    perubahan.kategori = kategoriBaru;
  }
  if (jumlahInput !== '') {
    if (!validasiJumlah(Number(jumlahInput))) {
      console.log('❌ Jumlah harus berupa bilangan bulat lebih dari 0.');
      return;
    }
    perubahan.jumlah = Number(jumlahInput);
  }
  if (tanggalBaru !== '') {
    if (!validasiTanggal(tanggalBaru)) {
      console.log('❌ Format tanggal salah. Gunakan YYYY-MM-DD.');
      return;
    }
    perubahan.tanggal = tanggalBaru;
  }

  if (Object.keys(perubahan).length === 0) {
    console.log('ℹ️  Tidak ada perubahan yang dilakukan.');
    return;
  }

  ubahPengeluaran(id, perubahan);
  console.log(`✅ Data ID ${id} berhasil diperbarui.`);
};

const handleHapus = async () => {
  console.log('\n--- Hapus Pengeluaran ---');
  handleLihat();
  const id = Number(await tanya('\nMasukkan ID yang ingin dihapus: '));

  if (!validasiId(id)) {
    console.log('❌ ID tidak valid.');
    return;
  }

  const dihapus = hapusPengeluaran(id);
  if (dihapus === null) {
    console.log(`❌ Data dengan ID ${id} tidak ditemukan.`);
    return;
  }

  console.log(`✅ "${dihapus.nama}" (ID ${id}) berhasil dihapus.`);
};

const handleCari = async () => {
  console.log('\n--- Cari Berdasarkan Kategori ---');
  const kategori = await tanya('Masukkan kategori: ');

  if (kategori === '') {
    console.log('❌ Kategori tidak boleh kosong.');
    return;
  }
  if (!adaKategori(kategori)) {
    console.log(`❌ Kategori "${kategori}" tidak ditemukan.`);
    return;
  }

  const hasil = filterByKategori(kategori);
  cetakTabel(hasil);
  console.log(`\nSubtotal kategori ${kategori}: ${formatRupiah(hitungTotal(hasil))}`);
};

const handleRingkasan = () => {
  cetakRingkasan(ringkasanPerKategori());
  console.log(`\nTotal keseluruhan: ${formatRupiah(hitungTotal())}`);
};

// ---------- Program utama ----------
const main = async () => {
  let berjalan = true;

  while (berjalan) {
    cetakMenu();
    const pilihan = await tanya('Pilih menu (0-6): ');

    switch (pilihan) {
      case '1':
        await handleTambah();
        break;
      case '2':
        handleLihat();
        break;
      case '3':
        await handleUbah();
        break;
      case '4':
        await handleHapus();
        break;
      case '5':
        await handleCari();
        break;
      case '6':
        handleRingkasan();
        break;
      case '0':
        berjalan = false;
        console.log('\nTerima kasih! Sampai jumpa 👋');
        break;
      default:
        console.log('❌ Pilihan tidak valid, silakan pilih angka 0-6.');
    }
  }

  tutupInput();
};

main();
