import readline from 'node:readline/promises';
import { stdin as input, stdout as output } from 'node:process';

const rl = readline.createInterface({ input, output });

export const tanya = async (pertanyaan) => {
  const jawaban = await rl.question(pertanyaan);
  return jawaban.trim();
};

export const tutupInput = () => rl.close();
