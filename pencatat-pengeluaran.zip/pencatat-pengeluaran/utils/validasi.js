export const validasiNama = (nama) => nama !== '' && nama.length <= 50;

export const validasiJumlah = (jumlah) =>
  !Number.isNaN(jumlah) && Number.isInteger(jumlah) && jumlah > 0;

export const validasiTanggal = (tanggal) => {
  const formatBenar = /^\d{4}-\d{2}-\d{2}$/.test(tanggal);
  if (!formatBenar) {
    return false;
  }
  const objekTanggal = new Date(tanggal);
  return !Number.isNaN(objekTanggal.getTime()) && objekTanggal.toISOString().slice(0, 10) === tanggal;
};

export const validasiId = (id) => !Number.isNaN(id) && Number.isInteger(id) && id > 0;
