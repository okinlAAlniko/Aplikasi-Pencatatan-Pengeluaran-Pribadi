export const formatRupiah = (angka) => `Rp${angka.toLocaleString('id-ID')}`;

export const cetakMenu = () => {
  console.log(`
==============================================
   PENCATAT PENGELUARAN HARIAN
==============================================
 1. Tambah pengeluaran
 2. Lihat semua pengeluaran
 3. Ubah pengeluaran
 4. Hapus pengeluaran
 5. Cari berdasarkan kategori
 6. Ringkasan per kategori
 0. Keluar
----------------------------------------------`);
};

export const cetakTabel = (daftar) => {
  if (daftar.length === 0) {
    console.log('(Belum ada data pengeluaran)');
    return;
  }

  console.log(`\n${'ID'.padEnd(4)}${'Tanggal'.padEnd(12)}${'Nama'.padEnd(22)}${'Kategori'.padEnd(16)}Jumlah`);
  console.log('-'.repeat(65));

  for (const { id, tanggal, nama, kategori, jumlah } of daftar) {
    console.log(`${String(id).padEnd(4)}${tanggal.padEnd(12)}${nama.padEnd(22)}${kategori.padEnd(16)}${formatRupiah(jumlah)}`);
  }
};

export const cetakRingkasan = (ringkasan) => {
  const entri = Object.entries(ringkasan);

  if (entri.length === 0) {
    console.log('(Belum ada data untuk diringkas)');
    return;
  }

  console.log('\nRingkasan pengeluaran per kategori:');
  for (const [kategori, total] of entri) {
    console.log(`- ${kategori.padEnd(16)}: ${formatRupiah(total)}`);
  }
};
